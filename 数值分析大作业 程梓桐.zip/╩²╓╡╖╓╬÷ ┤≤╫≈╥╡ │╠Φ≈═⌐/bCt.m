function [v] = bCt(A,K,a,c,x)
B=zeros(1,K);
for i=1:K
    B(i)=cos((i-1)*acos((2*x-(a+c))/(c-a)));
end
v=dot(A,B);
