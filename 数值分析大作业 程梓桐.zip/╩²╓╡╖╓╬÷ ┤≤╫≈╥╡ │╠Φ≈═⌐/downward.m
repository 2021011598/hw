function [mD,mrD,mlD,mE,mrE,mlE] = downward(mB,mlB,mrB,alD,blD,dlD,arE,brE,drE)
mD=mB;
mE=mB;
mlD=mlB;
mrE=mrB;
A=[1,arE;blD,1]\[mrB*(1-brE)-mB*drE;mlB*(1-alD)-mB*dlD];
mrD=A(1);
mlE=A(2);
end

