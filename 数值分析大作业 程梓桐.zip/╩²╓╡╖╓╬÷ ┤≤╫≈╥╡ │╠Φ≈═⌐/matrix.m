function [P] = matrix(pl,pr,gl,gr,K,a,c)
P=zeros(K);
u=Chebnode(a,c,K);
t=linspace((2*K-1)*pi/(2*K),pi/(2*K),K);
for j=1:K
    T=@(x)cos((acos((2*x-(a+c))/(c-a)))*(j-1));
    hl=lsim(fCt(gl,T,K,a,c),K,a,c);
    hr=rsim(fCt(gr,T,K,a,c),K,a,c);
    for i=1:K        
        P(i,j)=cos((j-1)*t(i))+dot(hl,T(u))*pl(u(i))+dot(hr,T(u))*pr(u(i));
    end
end
end

