F=@(a,b,c)2*b./c.^2;
p=@(a,b,c)4*b./c.^3;
q=@(a,b,c)-2*c.^(-2);
F=@(a,b,c)c.^2;
p=@(a,b,c)-2*c;
q=@(a,b,c)0;

Z=[1 0;1 0];
ga=[0;0];
u0=@(x)log(x);
a=1;
c=2;
K=16;
TOL=10^(-2);
m=4;
n=5;
C=20;
h=10^(-2);
v=algo3(F,p,q,Z,K,a,c,C,ga,n,TOL,h,u0,m);
x=linspace(0,2,1000);
y=zeros(1,1000);
for i=1:1000
    y(i)=v(x(i));
end
plot(x,y);
