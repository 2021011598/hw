function [w] = ww(c)
w=c(1).a+1;
end

