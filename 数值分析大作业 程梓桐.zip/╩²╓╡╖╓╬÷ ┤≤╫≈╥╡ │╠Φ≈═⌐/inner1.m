function [I] = inner1(w,g,K,a,c,b,d)
t=linspace((2*K-1)*pi/(2*K),pi/(2*K),K);
D=zeros(1,K);
u=Chebnode(a,c,K);
D(1)=(g(u)*w)/K;
for i=2:K
    D(i)=2*((g(u).*cos((i-1)*t))*w)/K;
end
A=lsim(D,K,a,c);
T=zeros(1,K);
for i=1:K
    T(i)=cos((i-1)*acos((2*d-a-c)/(c-a)))-cos((i-1)*acos((2*b-a-c)/(c-a)));
end
I=dot(A,T);

end

