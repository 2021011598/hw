function [I] = inner(f,g,B,K,a,c,b,d)
u=Chebnode(a,c,K);
t=linspace((2*K-1)*pi/(2*K),pi/(2*K),K);
w=f(u);
v=B\(w.');
D=zeros(1,K);
D(1)=(g(u)*v)/K;
for i=2:K
    D(i)=2*((g(u).*cos((i-1)*t))*v)/K;
end
A=lsim(D,K,a,c);
T=zeros(1,K);
for i=1:K
    T(i)=cos((i-1)*acos((2*d-a-c)/(c-a)))-cos((i-1)*acos((2*b-a-c)/(c-a)));
end
I=dot(A,T);
