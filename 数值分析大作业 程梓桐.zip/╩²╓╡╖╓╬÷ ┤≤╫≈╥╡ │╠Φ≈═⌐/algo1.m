function [v,u]= algo1(p,q,Z,ga,f,K,b,n)
a=b(1);
c=b(n+1);
W=Z;
W(2,2)=W(2,2)+Z(2,1)*(c-a);
A1=W\ga;
uia=A1(1);
k0=A1(2);
ui=@(x)k0*(x-a)+uia;
ft=@(x)f(x)-(k0*p(x)+ui(x).*q(x));
if (abs(Z(1,1))>= abs(Z(1,2)))||(abs(Z(2,1))>= abs(Z(2,2)))
    gl=@(x)Z(1,1)*(x-a)-Z(1,2);
    gr=@(x)Z(2,1)*(x-c)-Z(2,2);
    s=det(Z)+Z(1,1)*Z(2,1)*(c-a);
    pl=@(x)(Z(2,1)*p(x)+q(x).*gr(x))/s;
    pr=@(x)(Z(1,1)*p(x)+q(x).*gl(x))/s;
else 
    q=@(x)q(x)+1;
    gl=@(x)Z(1,2)*cosh(x-a)-Z(1,1)*sinh(x-a);
    gr=@(x)Z(2,2)*cosh(x-c)-Z(2,1)*sinh(x-c);
    s=det(Z)*cosh(c-a)+(Z(1,1)*Z(2,1)-Z(1,2)*Z(2,2))*sinh(c-a);
    pl=@(x)((Z(2,2)*sinh(x-c)-Z(2,1)*cosh(x-c)).*p(x)+q(x).*gr(x))/s;
    pr=@(x)((Z(1,2)*sinh(x-a)-Z(1,1)*cosh(x-a)).*p(x)+q(x).*gl(x))/s;
end
T=zeros(n,K);
A=zeros(n*K);
U=zeros(1,n*K);
v=zeros(1,n*K);
B=zeros(K,K);
B1=zeros(K,K);
Cl=zeros(K,K);
Cr=zeros(K,K);
for i=1:n
    T(i,:)=Chebnode(b(i),b(i+1),K);
end
for i=1:n
    for j=1:K
    U((i-1)*K+j)=T(i,j);
    end
end
for j=1:K
    for i=2:K
        B(j,i)=2*cos((i-1)*(2*K+1-2*j)*pi/(2*K));
    end
    B(j,1)=1;
    Cl(j,:)=lsim(B(j,:),K,-1,1);
    Cr(j,:)=rsim(B(j,:),K,-1,1);
end
for j=1:K
    for i=1:K
        B1(j,i)=cos((i-1)*(2*K+1-2*j)*pi/(2*K));
    end
end
for i=1:n
    for k=1:n
        for j=1:K
            for w=1:K
                if i>k
                    A((i-1)*K+j,(k-1)*K+w)=((b(k+1)-b(k))/2)*gl(T(k,w))*pl(T(i,j))*sum(Cl(w,:))/K;
                end
                if i<k
                    A((i-1)*K+j,(k-1)*K+w)=((b(k+1)-b(k))/2)*gr(T(k,w))*pr(T(i,j))*dot((-1).^(0:K-1),Cr(w,:))/K;
                end
                if i==k
                    A((i-1)*K+j,(k-1)*K+w)=((b(k+1)-b(k))/2)*(gr(T(i,w))*pr(T(i,j))*dot(Cr(w,:),B1(j,:))+gl(T(i,w))*pl(T(i,j))*dot(Cl(w,:),B1(j,:)))/K;
                end
            end
        end
    end
end
A=A+eye(n*K);
u=A\ft(U).';
jl=zeros(1,n);
jr=zeros(1,n+1);
jl(1)=0;
jr(n+1)=0;
for i=n+1:-1:2
    jr(i-1)=jr(i)+inner1(u((i-2)*K+1:(i-1)*K),gr,K,b(i-1),b(i),b(i-1),b(i));
end
for i=1:n
    jl(i+1)=jl(i)+inner1(u((i-1)*K+1:i*K),gl,K,b(i),b(i+1),b(i),b(i+1));
end
for i=1:n
    for k=1:K
         v((i-1)*K+k)=ui(T(i,k))+gr(T(i,k))*(jl(i)+inner1(u((i-1)*K+1:i*K),gl,K,b(i),b(i+1),b(i),T(i,k)))/s+gl(T(i,k))*(jr(i)+inner1(u((i-1)*K+1:i*K),gr,K,b(i),b(i+1),T(i,k),b(i+1)))/s;
    end
end
end



