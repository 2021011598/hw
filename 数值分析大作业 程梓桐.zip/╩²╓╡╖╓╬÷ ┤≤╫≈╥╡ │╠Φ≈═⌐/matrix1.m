function [G] = matrix1(pl,pr,gl,gr,K,a,c,F)
P=zeros(K);
u=Chebnode(a,c,K);
t=linspace((2*K-1)*pi/(2*K),pi/(2*K),K);
for i=1:K
    for j=1:K 
        tl=@(x)gl(x)*cos((acos((2*x-(a+c))/(c-a)))*j);
        tr=@(x)gr(x)*cos((acos((2*x-(a+c))/(c-a)))*j);
        hl=bCt(lsim(fCt(tl,K,a,c),K,a,c),K,a,c);
        hr=bCt(rsim(fCt(tr,K,a,c),K,a,c),K,a,c);
        P(i,j)=cos((j-1)*t(i))+hl(u(i))*pl(u(i))+hr(u(i))*pr(u(i));
    end
end
G=P\F(u.');
end
