function [alB,arB,blB,brB,dlB,drB] = upward(alD,arD,blD,brD,dlD,drD,alE,arE,blE,brE,dlE,drE)
D=1-arE*blD;
alB=(1-alE)*(alD-blD*arE)/D+alE;
arB=arE*(1-brD)*(1-alD)/D+arD;
blB=blD*(1-alE)*(1-brE)/D+blE;
brB=(1-brD)*(brE-blD*arE)/D+brD;
dlB=(dlD-drE*blD)*(1-alE)/D+dlE;
drB=(drE-dlD*arE)*(1-brD)/D+drD;
end

