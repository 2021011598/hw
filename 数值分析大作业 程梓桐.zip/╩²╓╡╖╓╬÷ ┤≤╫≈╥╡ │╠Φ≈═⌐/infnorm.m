function [x] = infnorm(f,a,c)
t=linspace(a,c,100);
v=zeros(1,100);
for j=1:100
    v(j)=abs(f(t(j)));
end
x=max(v);
end

