function [y] = interplo1(x,u,v,n)
y=1;
for i=1:n-1
    if ((x>=u(i)) & (x<u(i+1)))
        y=v(i)+(v(i+1)-v(i))*(x-u(i))/(u(i+1)-u(i));
    end
end
    if  x<u(1)
        y=v(1);
    elseif x>=u(n)
        y=v(n);
    end

end

