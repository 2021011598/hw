function [B] = rsim(f,K,a,c)
B=zeros(1,K);
for j=3:K-1
    B(j)=(f(j+1)-f(j-1))/(2*(j-1));
end
B(K)=-f(K-1)/(2*(K-1));
B(2)=f(3)/2-f(1);
B(1)=-sum(B(2:K));
B=((c-a)/2)*B;
end

