function [h] = multiply(f,g)
h=@(x)f(x)*g(x);
end

