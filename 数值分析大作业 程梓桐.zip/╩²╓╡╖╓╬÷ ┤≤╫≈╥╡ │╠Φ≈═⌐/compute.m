function [U] = compute(inte,s,K,pl,pr,gl,gr,n,ui,ft)
j=0;
Y=zeros(2,n);
for i=n:-1:1
    if (inte(i).l==-1)&(inte(i).d==1)
        j=j+1;       
        a=inte(i).lp;
        c=inte(i).rp;
        Y(:,j)=[i;a];
        A=inte(i).mat;       
        inte(i).al=inner(pl,gl,A,K,a,c,a,c);
        inte(i).ar=inner(pl,gr,A,K,a,c,a,c);
        inte(i).bl=inner(pr,gl,A,K,a,c,a,c);
        inte(i).br=inner(pr,gr,A,K,a,c,a,c);
        inte(i).dl=inner(ft,gl,A,K,a,c,a,c);
        inte(i).dr=inner(ft,gr,A,K,a,c,a,c);
    else
        L=inte(i).l;
        R=inte(i).r;
        [inte(i).al,inte(i).ar,inte(i).bl,inte(i).br,inte(i).dl,inte(i).dr]=upward(inte(L).al,inte(L).ar,inte(L).bl,inte(L).br,inte(L).dl,inte(L).dr,inte(R).al,inte(R).ar,inte(R).bl,inte(R).br,inte(R).dl,inte(R).dr);
    end
end
for i=1:n
    if ((inte(i).l~=-1)&(inte(i).d==1))
        L=inte(i).l;
        R=inte(i).r;
        [inte(L).m,inte(L).mr,inte(L).ml,inte(R).m,inte(R).mr,inte(R).ml]=downward(inte(i).m,inte(i).mr,inte(i).ml,inte(L).al,inte(L).bl,inte(L).dl,inte(R).ar,inte(R).br,inte(R).dr);
    end
end
[~,Z]=sort(Y(2,1:j));
V=Y(1,Z);
jl=zeros(1,j);
jr=zeros(1,j);
jl(1)=0;
jr(j)=0;
a0=zeros(1,j);
c0=zeros(1,j);
for i=1:j
c0(i)=inte(V(i)).rp;
a0(i)=inte(V(i)).lp;
end
for i=j:-1:2
    jr(i-1)=jr(i)+inte(V(i)).dr+inte(V(i)).ml*inte(V(i)).ar+inte(V(i)).mr*inte(V(i)).br;
end
for i=1:j-1
    jl(i+1)=jl(i)+inte(V(i)).dl+inte(V(i)).ml*inte(V(i)).al+inte(V(i)).mr*inte(V(i)).bl;
end
u=zeros(j,K);
u0=zeros(1,j*K);
v0=zeros(1,j*K);
for i=1:j
    w=inte(V(i)).cheb;
    for k=1:K
        B=matrix(pl,pr,gl,gr,K,a0(i),c0(i));
        u(i,k)=ui(w(k))+gr(w(k))*(jl(i)+inner(ft,gl,B,K,a0(i),c0(i),a0(i),w(k)))/s+gl(w(k))*(jr(i)+inner(ft,gr,B,K,a0(i),c0(i),w(k),c0(i)))/s;
        u0((i-1)*K+k)=u(i,k);
        v0((i-1)*K+k)=w(k);
    end
end
U=@(x)interplo1(x,v0,u0,j*K);
end
