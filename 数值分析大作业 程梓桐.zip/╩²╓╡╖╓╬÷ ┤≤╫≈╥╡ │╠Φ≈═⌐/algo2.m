function [v,er] = algo2(p,q,Z,ga,f,K,a,c,C,TOL,m)
W=Z;
W(2,2)=W(2,2)+Z(2,1)*(c-a);
A1=W\ga;
uia=A1(1);
k0=A1(2);
ui=@(x)k0*(x-a)+uia;
ft=@(x)f(x)-(k0*p(x)+ui(x).*q(x));
if (abs(Z(1,1))>= abs(Z(1,2)))||(abs(Z(2,1))>= abs(Z(2,2)))
    gl=@(x)Z(1,1)*(x-a)-Z(1,2);
    gr=@(x)Z(2,1)*(x-c)-Z(2,2);
    s=det(Z)+Z(1,1)*Z(2,1)*(c-a);
    pl=@(x)(Z(2,1)*p(x)+q(x).*gr(x))/s;
    pr=@(x)(Z(1,1)*p(x)+q(x).*gl(x))/s;
else 
    q=@(x)q(x)+1;
    gl=@(x)Z(1,2)*cosh(x-a)-Z(1,1)*sinh(x-a);
    gr=@(x)Z(2,2)*cosh(x-c)-Z(2,1)*sinh(x-c);
    s=det(Z)*cosh(c-a)+(Z(1,1)*Z(2,1)-Z(1,2)*Z(2,2))*sinh(c-a);
    pl=@(x)((Z(2,2)*sinh(x-c)-Z(2,1)*cosh(x-c)).*p(x)+q(x).*gr(x))/s;
    pr=@(x)((Z(1,2)*sinh(x-a)-Z(1,1)*cosh(x-a)).*p(x)+q(x).*gl(x))/s;
end
M=0;
inte=struct('lp',[],'rp',[],'al',[],'ar',[],'bl',[],'br',[],'dl',[],'dr',[],'m',[],'ml',[],'mr',[],'mat',[],'cheb',[],'l',[],'r',[],'d',[],'p',[]);
n=1;
inte(1).d=1;
inte(1).lp=a;
inte(1).rp=c;
inte(1).l=-1;
inte(1).r=-1;
inte(1).m=1;
inte(1).ml=0;
inte(1).mr=0;
inte(1).mat=matrix(pl,pr,gl,gr,K,a,c);
inte(1).cheb=Chebnode(a,c,K);
U2=compute(inte,s,K,pl,pr,gl,gr,n,ui,ft);
while 1
    S=zeros(1,n);
    for i=1:n
        if (inte(i).l==-1)&&((inte(i).d==1))
            C0=inte(i).mat;
            S(i)=abs(C0(K-1))+abs(C0(K)-C0(K-2));
        end
    end
    Sdiv=max(S)/2^C;
    k=n;
    for i=1:n
        if ((S(i)>=Sdiv)&&(inte(i).l==-1)&&(inte(i).d==1))           
            inte(k+1).lp=inte(i).lp;
            inte(k+1).rp=(inte(i).lp+inte(i).rp)/2;
            inte(k+1).l=-1;
            inte(k+1).r=-1;
            inte(k+1).p=i;
            inte(k+1).d=1;
            inte(k+1).mat=matrix(pl,pr,gl,gr,K,inte(k+1).lp,inte(k+1).rp);
            inte(k+1).cheb=Chebnode(inte(k+1).lp,inte(k+1).rp,K);
            inte(i).l=k+1;
            inte(k+2).lp=(inte(i).lp+inte(i).rp)/2;
            inte(k+2).rp=inte(i).rp;
            inte(k+2).l=-1;
            inte(k+2).r=-1;
            inte(k+2).p=i;
            inte(k+2).d=1;
            inte(k+2).mat=matrix(pl,pr,gl,gr,K,inte(k+2).lp,inte(k+2).rp);
            inte(k+2).cheb=Chebnode(inte(k+2).lp,inte(k+2).rp,K);
            inte(i).r=k+2;
            k=k+2;
        end
        if ((i+1<=n)&&(S(i)+S(i+1)<Sdiv/2^K)&&(inte(i).l==-1)&&(inte(i).d==1)&&(inte(i+1).l==-1)&&(inte(i+1).d==1)&&(inte(i).p==inte(i+1).p))
            inte(i).d=0;
            inte(i+1).d=0;
            g=inte(i).p;
            inte(g).l=-1;
            inte(g).r=-1;
        end
    end
    n=k;
    U1=U2;
    U2=compute(inte,s,K,pl,pr,gl,gr,n,ui,ft);
    V1=@(x)U1(x)-U2(x);
    V2=@(x)U1(x)+U2(x);
    if ((infnorm(V1,a,c)<infnorm(V2,a,c)*TOL)||(M==m))
        break
    end
    M=M+1;
end
v=U2;
k=n;
for i=1:n
    if ((inte(i).l==-1)&&(inte(i).d==1))      
        inte(k+1).lp=inte(i).lp;
        inte(k+1).rp=(inte(i).lp+inte(i).rp)/2;
        inte(k+1).mat=matrix(pl,pr,gl,gr,K,inte(k+1).lp,inte(k+1).rp);
        inte(k+1).cheb=Chebnode(inte(k+1).lp,inte(k+1).rp,K);
        inte(k+2).lp=(inte(i).lp+inte(i).rp)/2;
        inte(k+2).rp=inte(i).rp;
        inte(k+2).mat=matrix(pl,pr,gl,gr,K,inte(k+2).lp,inte(k+2).rp);
        inte(k+2).cheb=Chebnode(inte(k+2).lp,inte(k+2).rp,K);
        inte(i).l=k+1;
        inte(i).r=k+2;
        inte(k+2).l=-1;
        inte(k+2).r=-1;
        inte(k+1).l=-1;
        inte(k+1).r=-1;
        inte(k+1).p=i;
        inte(k+1).d=1;
        inte(k+2).p=i;
        inte(k+2).d=1;
        k=k+2;
    end
end
n=k;
U3=compute(inte,s,K,pl,pr,gl,gr,n,ui,ft);
V3=@(x)U2(x)-U3(x);
er=infnorm(V3,a,c);








