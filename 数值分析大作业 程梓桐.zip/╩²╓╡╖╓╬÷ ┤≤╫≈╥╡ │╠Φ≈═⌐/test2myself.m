p=@(x)0;
q=@(x)0;
f=@(x)0;
K=16;
a=0;
c=1;
C=20;
TOL=10^(-4);
Z=[1 0;1 0];
ga=[0;1];
m=9;
[v,er]=algo2(p,q,Z,ga,f,K,a,c,C,TOL,m);
x=linspace(0,1,1000);
y=zeros(1,1000);
for i=1:1000
    y(i)=v(x(i));
end
plot(x,y);
