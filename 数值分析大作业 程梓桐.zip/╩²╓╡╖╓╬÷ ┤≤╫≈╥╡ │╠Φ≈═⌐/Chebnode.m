function [t] = Chebnode(a,c,K)
t=((c-a)/2)*cos(linspace((2*K-1)*pi/(2*K),pi/(2*K),K))+(a+c)/2;
