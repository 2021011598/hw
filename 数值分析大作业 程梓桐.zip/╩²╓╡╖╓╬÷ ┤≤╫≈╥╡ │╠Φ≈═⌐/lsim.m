function [A] = lsim(f,K,a,c)
A=zeros(1,K);
for j=3:K-1
    A(j)=(f(j-1)-f(j+1))/(2*(j-1));
end
A(K)=f(K-1)/(2*(K-1));
A(2)=f(1)-f(3)/2;
A(1)=dot((-1).^(2:K),A(2:K));
A=((c-a)/2)*A;
end

