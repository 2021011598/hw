function [f] = G(v,x,K,a,c)
z=zeros(1,K);
for j=1:K
    z(j)= cos((j-1)*acos((2*x-(a+c))/(c-a)));
end
f=z*v;
end

