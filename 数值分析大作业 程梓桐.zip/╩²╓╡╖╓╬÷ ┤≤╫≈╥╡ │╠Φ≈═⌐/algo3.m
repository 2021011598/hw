function [u] = algo3(F,p,q,Z,K,a,c,C,ga,n,TOL,h,u0,m)
for i=1:n
    px=@(x)p(x,u0(x),(u0(x+h)-u0(x))/h);
    qx=@(x)q(x,u0(x),(u0(x+h)-u0(x))/h);
    fx=@(x)F(x,u0(x),(u0(x+h)-u0(x))/h)-(u0(x+h)+u0(x-h)-2*u0(x))/h^2;
    [d,er]=algo2(px,qx,Z,ga,fx,K,a,c,C,TOL,m);
    u0=@(x)u0(x)+d(x);
end
u=u0;
