e=10^(-9);
p=@(x)2*x/e;
q=@(x)0;
f=@(x)0;
K=16;
a=0;
c=1;
N=25;
b=linspace(a,c,N);
Z=[1 0;1 0];
ga=[0;1];
[U,u]=algo1(p,q,Z,ga,f,K,b,N-1);
x=linspace(a,c,N-1);
y=zeros(1,N-1);
for i=1:N-1
    y(i)=interplo1(x(i),x,U,N-1);
end
plot(x,y);