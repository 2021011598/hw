function [A] = fCt(f,g,K,a,c)
A=zeros(1,K);
v=Chebnode(a,c,K);
B=f(v).*g(v);
A(1)=sum(B)/K;
for j=2:K 
    C=cos((j-1)*linspace((2*K-1)*pi/(2*K),pi/(2*K),K));
    A(j)=2*dot(B,C)/K;
end

