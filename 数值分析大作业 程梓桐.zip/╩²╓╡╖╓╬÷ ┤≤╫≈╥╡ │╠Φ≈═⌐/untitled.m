f=@(x)x;
c=inner(f,f,eye(10),10,-1,1,-1,1);